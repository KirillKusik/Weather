#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "TSSettings.h"
#import "TSSQLiteDB.h"

@interface TSDB : NSObject

-(void) addRecordToDatabase:(NSDictionary *) dictionary;
-(void) deleteRecordFromDatabase:(id)recordID;
-(void) refresh;
-(void) removeUnneededRecords;

-(NSArray *) getWeather;

-(void) sqlToCoreData;
-(void) coreDataToSql;

@end
