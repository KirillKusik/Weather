#import <Foundation/Foundation.h>
#import "SQLiteAccess.h"

static NSString * const kSqlDatabaseTableName = @"weatherInf";
static NSString * const kSqlDatabaseKey_ID = @"id";
static NSString * const kSqlDatabaseKey_City = @"city";
static NSString * const kSqlDatabaseKey_Code = @"code";
static NSString * const kSqlDatabaseKey_Date = @"date";
static NSString * const kSqlDatabaseKey_Temp = @"temp";
static NSString * const kSqlDatabaseKey_Text = @"text";

@interface TSSQLiteDB : NSObject{
    NSMutableArray *arrayOfRecordsFromDatabase;
}

-(void) removeUnneededRecords;
-(void) addRecordToDatabase:(NSDictionary *) dictionary;
-(void) deleteRecordFromDatabase:(NSUInteger)recordID;
-(NSArray *)getArrayOfRecordsFromDatabase;

@end
