//
//  WeatherDB.m
//  Weather
//
//  Created by Admin on 26.05.14.
//  Copyright (c) 2014 123. All rights reserved.
//

#import "WeatherDB.h"


@implementation WeatherDB

@dynamic city;
@dynamic code;
@dynamic date;
@dynamic temp;
@dynamic text;

@end
