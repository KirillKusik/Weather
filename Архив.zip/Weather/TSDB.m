/*
 Класс работает с обееми (SQLait и CoreData) базами данных автоматически подключаясь к той, 
 которая сейчас указана активной в настройках
 
 поля баз данных
 id (integer) - автоинкрементирующийся счетчик
 city (string) - назнание города
 code (string) - код обозначающий погодные условия в Yahoo Weather (0 tornado, 1 tropical storm, 2 hurricane и т.д)
 date (string) - дата запроса погоды
 temp (integer) - температура
 text (string) - краткое примечание про облачность, осадки и т.д.
*/

#import "TSDB.h"
#import "TSSQLiteDB.h"
#import "TSAppDelegate.h"

@implementation TSDB

//********************************************
//Метод копирует поля из coreData в SQLite после чего очишает исходную базу
-(void) coreDataToSql{
    TSAppDelegate *coreDataDatabace = [TSAppDelegate new];
    TSSQLiteDB *sqlDatabase = [TSSQLiteDB new];
    
    //перезапись полей из coreData в SQLite
    for (NSDictionary *dic in coreDataDatabace.linsArray){
        [sqlDatabase addRecordToDatabase:dic];
        
// (!!!) когда исправлю метод кореДата заменить @"id" на символьную константу
        [coreDataDatabace deleteRecordFromDatabase:[dic objectForKey:@"id"]];
    }
}


//********************************************
//Метод копирует поля из SQLite в coreData после чего очишает исходную базу
-(void) sqlToCoreData{
    TSAppDelegate *coreDataDatabase = [TSAppDelegate new];
    TSSQLiteDB *sqlDatabase = [TSSQLiteDB new];
    NSArray *sqlDatabase_RecordsArray = [NSArray arrayWithArray:[sqlDatabase getArrayOfRecordsFromDatabase]];
    
    //перезапись полей из SQLite в coreData
    for (NSDictionary *dic in sqlDatabase_RecordsArray){
        [coreDataDatabase addRecordToDatabase:dic];
        [sqlDatabase deleteRecordFromDatabase:[[dic objectForKey:kSqlDatabaseKey_ID] integerValue]];
    }
}

//********************************************
//Метод удалит лишние поля (начиная от самых старых)
//если в базе данных полей больше чем указанно в настройках
-(void) removeUnneededRecords{
    if ([[TSSettings sharedController] DBType]){
        TSAppDelegate *coreData = [TSAppDelegate new];
        [coreData removeUnneededRecords];
    }
    else{
        TSSQLiteDB *sqlDatabace = [TSSQLiteDB new];
        [sqlDatabace removeUnneededRecords];
    }
}

//********************************************
//Метод добавляет новое поле с значениями из NSDictionary
-(void) addRecordToDatabase:(NSDictionary *)dictionary{
    if ([[TSSettings sharedController] DBType]){
        TSAppDelegate *coreData = [TSAppDelegate new];
        [coreData addRecordToDatabase:dictionary];
    }
    else{
        TSSQLiteDB *sqlDatabase = [TSSQLiteDB new];
        [sqlDatabase addRecordToDatabase:dictionary];
    }
}


//********************************************
//Метод удаляет поле с указанным id
-(void)deleteRecordFromDatabase:(id)recordID{
    if ([[TSSettings sharedController] DBType]){
        TSAppDelegate *coreData = [TSAppDelegate new];
        [coreData deleteRecordFromDatabase:recordID];
    }
    else{
        TSSQLiteDB *mysql = [TSSQLiteDB new];
        [mysql deleteRecordFromDatabase:[recordID integerValue]];
    }
}

//********************************************
//Метод обновляет массив записей в базе
-(void)refresh{
    if ([[TSSettings sharedController] DBType]){
        TSAppDelegate *coreData = [TSAppDelegate new];
        [coreData refresh];
    }
}

//********************************************
//Метод возвращает из базы данных массив записей (NSDictionary)
-(NSArray *)getWeather{
    if ([[TSSettings sharedController] DBType]){
        TSAppDelegate *coreData = [TSAppDelegate new];
        return coreData.linsArray;
    }
    else{
        return [[TSSQLiteDB new] getArrayOfRecordsFromDatabase];
    }
}

@end
