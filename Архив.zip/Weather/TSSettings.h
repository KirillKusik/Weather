//
//  TSSettings.h
//  Weather
//
//  Created by Admin on 19.05.14.
//  Copyright (c) 2014 123. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TSSettings : NSObject{
    NSUInteger limitRecordsInDatabase;
    NSString *addresDbHost;
}
@property(nonatomic) BOOL DBType;
@property(nonatomic) NSUInteger limitRecordsInDatabase;
@property(nonatomic) NSString *addresDbHost;


/*-(void) setDBType:(BOOL)type;
-(BOOL) DBType;

-(void) setDBCount:(NSUInteger)count;
-(NSUInteger)DBCount;
*/


+(instancetype) sharedController;

-(void)saveSettings;

@end
