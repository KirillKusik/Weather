//
//  TSSecondViewController.h
//  Weather
//
//  Created by Admin on 13.05.14.
//  Copyright (c) 2014 123. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TSSecondViewController : UIViewController{
    IBOutlet UILabel *dbCount;
    IBOutlet UISegmentedControl *DBChengControl;
    IBOutlet UIButton *changHostName;
    IBOutlet UITextField *hostAddres;
}

//@property (nonatomic,weak) UITextField *dbCount;






@end
