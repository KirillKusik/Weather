/*
 Класс обеспечивает доступ к базе данных SQLite.
 
 Класс специализирует базу ограничивая лишние функции которые не применяются в данном приложении. 
 Также берет на себя формирование SQL запросов.
*/

#import "TSSQLiteDB.h"
#import "TSSettings.h"

@implementation TSSQLiteDB

//********************************************
//метод возврашает масив всех записей (NSDictionary) хранящихся в базе SQLite
-(NSArray *)getArrayOfRecordsFromDatabase{
    return [SQLiteAccess selectManyRowsWithSQL:[NSString stringWithFormat:@"select * FROM %@", kSqlDatabaseTableName]];
}


//********************************************
//метод удаляет старые записи если их боьше чем указанно в настройках
-(void) removeUnneededRecords{
    for (NSInteger i = 0; [[self getArrayOfRecordsFromDatabase] count] > [[TSSettings sharedController] limitRecordsInDatabase]; i++) {
        NSDictionary * recordFoDeleted = [[self getArrayOfRecordsFromDatabase] objectAtIndex:0];
        [self deleteRecordFromDatabase:[[recordFoDeleted objectForKey:kSqlDatabaseKey_ID] unsignedIntegerValue]];
    }
}


//********************************************
//метод добавляет запись в SQLite и следит что-бы
//база не содержала лишних записей
-(void)addRecordToDatabase:(NSDictionary *) dictionary{
    NSString *queryInsert = [NSString stringWithFormat:
                             @"insert into %@ ('%@','%@','%@', %@,'%@') values ('%@','%@','%@','%@','%@')",
                             kSqlDatabaseTableName,
                             kSqlDatabaseKey_City,
                             kSqlDatabaseKey_Code,
                             kSqlDatabaseKey_Date,
                             kSqlDatabaseKey_Temp,
                             kSqlDatabaseKey_Text,
                             [dictionary objectForKey:kSqlDatabaseKey_City],
                             [dictionary objectForKey:kSqlDatabaseKey_Code],
                             [dictionary objectForKey:kSqlDatabaseKey_Date],
                             [dictionary objectForKey:kSqlDatabaseKey_Temp],
                             [dictionary objectForKey:kSqlDatabaseKey_Text]];
    
    [SQLiteAccess updateWithSQL:queryInsert];

    [self removeUnneededRecords];
}


//********************************************
//метод удаляет запись из базы по указанному ID
-(void)deleteRecordFromDatabase:(NSUInteger)recordID{
    [SQLiteAccess deleteWithSQL:[NSString stringWithFormat:@"DELETE FROM %@ WHERE %@ = %lu;",kSqlDatabaseTableName, kSqlDatabaseKey_ID, (unsigned long)recordID]];
}

@end
